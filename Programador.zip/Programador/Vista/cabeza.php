<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Inventario Sena</title>
  <link rel="shortcut icon" type="image/x-icon" href="<?php echo PUBLIC_PATH ?>img/icono.ico" />
  <!-- DataTables -->
    <link href="<?php echo PUBLIC_PATH ?>css/datatables.min.css" rel="stylesheet">
<!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/jq-3.3.1/jszip-2.5.0/dt-1.10.18/af-2.3.3/b-1.5.6/b-colvis-1.5.6/b-flash-1.5.6/b-html5-1.5.6/b-print-1.5.6/cr-1.5.0/fc-3.2.5/fh-3.1.4/kt-2.5.0/r-2.2.2/rg-1.1.0/rr-1.2.4/sc-2.0.0/sl-1.3.0/datatables.min.css"/> -->


    <!-- tabla responsive -->
   <!--  <link rel="stylesheet" href="<../../assets/template/datatables.net-bs/css/responsive.dataTables.min.css"> -->
  <!-- fin datatables -->
  <!-- DataTables -->

  
    <link href="<?php echo PUBLIC_PATH ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  
    <!-- Custom styles for this template-->
    <link href="<?php echo PUBLIC_PATH ?>css/sb-admin-2.css" rel="stylesheet">
    <!--DISEÑO PORPIO-->
    <link href="<?php echo PUBLIC_PATH ?>css/main.css" rel="stylesheet">
    <!--ANIMACIONES-->
    <link href="<?php echo PUBLIC_PATH ?>css/animate.css" rel="stylesheet">
    <!-- FILE INPUT -->
    <link href="<?php echo PUBLIC_PATH ?>css/fileinput.css" rel="stylesheet">
    <link href="<?php echo PUBLIC_PATH ?>css/fileinput.min.css" rel="stylesheet">

    <!--LOGIN-->
  <!--   <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <script src="sweetalert2.all.min.js"></script>
    <!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
    <script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
    <!------ Include the above in your HEAD tag ---------->

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">



  </head>