<?php 
   define('BASE_URL', 'https://johancrespo.000webhostapp.com/inventario/pruebaDos/Programador/');
  //define('BASE_URL', 'http://www.gestionedu.co/inventario/programador/');
  define('PUBLIC_PATH', BASE_URL . 'public/'); 
  define('VISTA_PATH',ROOT.DS.'Vista'.DS);
  define('CONTROL_PATH',ROOT.DS.'app'.DS.'controlador'.DS);
  define('MODELO_PATH',ROOT.DS.'app'.DS.'modelo'.DS);
  define('LIB_PATH',ROOT.DS.'app'.DS.'lib'.DS);
 ?>